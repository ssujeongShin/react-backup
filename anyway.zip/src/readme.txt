commonComponent : header, sideGNB, footer, topmenu

contentComponent : 각 페이지

structureComponent > 각 페이지 이름 폴더 > 각 페이지 디테일 구조